import { Component, OnInit } from '@angular/core';
import { AlertifyService } from '../_services/alertify.service';
import { AuthService } from '../_services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  model: any = {};

  constructor(
    private alertify: AlertifyService,
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit() {
  }

  login() {
    // tslint:disable-next-line: prefer-const
    let msg = this.authService.verifyLogin(this.model);

    if (msg) {
      this.alertify.success('Login Sucessfull..!!');
      this.router.navigateByUrl('/shedule');
    } else {
      this.alertify.error('Login Falied..!!!');
    }
  }
}
