import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, JsonpModule } from '@angular/http';


import { AppComponent } from './app.component';
import { NavComponent } from './nav/nav.component';
import { RouterModule } from '@angular/router';
import { appRoutes } from './routes';
import { LoginComponent } from './login/login.component';
import { AlertifyService } from './_services/alertify.service';
import { AuthService } from './_services/auth.service';
import { SheduleComponent } from './shedule/shedule.component';
import { CommonModule} from '@angular/common';
import { ScheduleAllModule, RecurrenceEditorAllModule } from '@syncfusion/ej2-angular-schedule';
import { DatePickerAllModule, TimePickerAllModule, DateTimePickerAllModule } from '@syncfusion/ej2-angular-calendars';
import { CheckBoxAllModule, ButtonModule } from '@syncfusion/ej2-angular-buttons';
import { ToolbarAllModule, TreeViewModule, TabModule } from '@syncfusion/ej2-angular-navigations';
import { DropDownListAllModule, MultiSelectAllModule, DropDownListModule } from '@syncfusion/ej2-angular-dropdowns';
import { MaskedTextBoxModule, NumericTextBoxAllModule } from '@syncfusion/ej2-angular-inputs';
import { RichTextEditorAllModule } from '@syncfusion/ej2-angular-richtexteditor';
import { ListViewModule } from '@syncfusion/ej2-angular-lists';
@NgModule({
   declarations: [
      AppComponent,
      NavComponent,
      LoginComponent,
      SheduleComponent
   ],
   imports: [
      BrowserModule,
      FormsModule,
      ReactiveFormsModule,
      RouterModule.forRoot(appRoutes),
      CommonModule,
      // tslint:disable-next-line: deprecation
      HttpModule,
      ScheduleAllModule,
      RecurrenceEditorAllModule,
      NumericTextBoxAllModule,
      DatePickerAllModule,
      TimePickerAllModule,
      DateTimePickerAllModule,
      CheckBoxAllModule,
      ToolbarAllModule,
      DropDownListAllModule,
      MaskedTextBoxModule,
      MultiSelectAllModule,
      ButtonModule,
      ListViewModule,
      DropDownListModule,
      TreeViewModule,
      TabModule,
      RichTextEditorAllModule,
      // tslint:disable-next-line: deprecation
      JsonpModule
   ],
   providers: [
      AlertifyService,
      AuthService
   ],
   bootstrap: [
      AppComponent
   ]
})
export class AppModule { }
