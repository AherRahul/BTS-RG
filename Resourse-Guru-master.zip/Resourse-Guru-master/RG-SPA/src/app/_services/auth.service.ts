import { Injectable } from '@angular/core';
import { users } from '../JSON_Data/data-source';

@Injectable()
export class AuthService {

constructor() { }

    verifyLogin(userModel) {
        if (userModel) {
            // tslint:disable-next-line: prefer-const
            let userArray = users;
            // tslint:disable-next-line: no-var-keyword
            // tslint:disable-next-line: prefer-for-of
            for (let i = 0; i < userArray.length; i++) {
               
                return true;
            }

            return false;
        }
        return false;
    }

}
