import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SheduleComponent } from './shedule/shedule.component';

export const appRoutes: Routes = [
    {
        path: '',
        component: LoginComponent
    },
    {
        path: 'shedule',
        component: SheduleComponent
    },
    {
        path: '**',
        redirectTo: '',
        pathMatch: 'full'
    }
];
